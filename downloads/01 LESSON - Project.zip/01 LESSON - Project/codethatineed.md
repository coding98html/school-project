## About LTS

```html
<section id="about_lts">
            <h2>About <abbr title="The Little Taco Shop">LTS</abbr></h2>
            <p><abbr title="The Little Taco Shop">LTS</abbr> was founded in <time datetime="2022">2022</time>. Our shop was built from a <b>love of tacos 🌮🌮🌮</b>. We hope our shop adds a unique and  interesting place to our little town</p>
            <h3>Taco Trivia</h3>
            <aside>
                <details>
                    <summary>When did tacos first appear in the United States</summary><p>Jeffrey M. Pilcher, professor of history at the University of Minnesota, says the earliest mention of tacos in the United States are in a newspaper from <time datetime="1905">1905</time></p>
                </details>
               </aside>
        </section>
```

## Menu (Prices, not nav menu!)

```html
<section id="menu">
            <table>
                <caption>Our Tacos</caption>
                <thead>
                    <tr>
                        <th scope="col">Tacos</th>
                        <th scope="col"><abbr title="Quality">Qty</abbr></th>
                        <th scope="col">Price</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th rowspan="3" scope="col">Crunchy</th>
                        <td>
                            1
                        </td>
                        <td scope="row">$1.50</td>
                    </tr>
                    <tr>
                        <td>
                            2
                        </td>
                        <td>$2.50</td>
                    </tr>
                    <tr>
                        <td>
                            3
                        </td>
                        <td>
                            $3.25
                        </td>
                    </tr>
                    <tr>
                        <th rowspan="3">Soft</th>
                        <td>
                            1
                        </td>
                        <td>
                            $2.00
                        </td>
                    </tr>
                    <tr>
                      <td>
                        2
                      </td>
                      <td>
                        $3.50
                      </td>  
                    </tr>
                    <tr>
                        <td>
                            3
                        </td>
                        <td>
                            $4.50
                        </td>
                    </tr>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="3">Chips and Salsa $2.00</td>
                    </tr>
                </tfoot>
            </table>
        </section>
```

## Back to Top code - for the bottom of (index.html)

```html
<a href="/">Back to Top</a>
```